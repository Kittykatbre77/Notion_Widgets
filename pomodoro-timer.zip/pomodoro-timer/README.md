# Pomodoro Timer

A Pen created on CodePen.io. Original URL: [https://codepen.io/ki66kfijnigjr/pen/jOjGerR](https://codepen.io/ki66kfijnigjr/pen/jOjGerR).

A project for freeCodeCamp's Frontend Development Libraries certification. This project was built with the ReactJS (class components) and FontAwesome libraries, as well as vanilla CSS.